from lm_eval.eval_main import *
import argparse
from tqdm import tqdm


if __name__ == '__main__':
    device = 'cuda:2'
    model_path = 'pretrained=/home/ET/jtfan/MyData/Models/DeepSeek-R1-Distill-Qwen-1.5B'
    # 'sciq' || 'winogrande' || 'arc_easy' || 'arc_challenge (25-shot)' || 'hellaswag (10-shot)' || 'bool_q (32-shot)' || 'nq (32-shot)' ||

    task_list = {
        'sciq' : 0,
        'winogrande' : 0,
        'arc_easy' : 0,
        'arc_challenge' : 25,
        'hellaswag' : 10,
    }

    results_dict = {}
    for task_name, num_shot in tqdm(task_list.items()):
        if num_shot != 0:
            parser = argparse.ArgumentParser()
            parser.add_argument("--model", default='hf')
            parser.add_argument("--model_args", default=model_path)
            parser.add_argument("--tasks", default=task_name)
            parser.add_argument("--device", default=device)
            parser.add_argument("--batch_size", default='auto:4')
            parser.add_argument("--num_fewshot", default=num_shot)
            parsed_args = parser.parse_args()
            results = cli_evaluate(parsed_args)
            score = results['results'][task_name]['acc,none']
            results_dict[task_name] = score
            print("")
        else:
            parser = argparse.ArgumentParser()
            parser.add_argument("--model", default='hf')
            parser.add_argument("--model_args", default=model_path)
            parser.add_argument("--tasks", default=task_name)
            parser.add_argument("--device", default=device)
            parser.add_argument("--batch_size", default='auto:4')
            parsed_args = parser.parse_args()
            results = cli_evaluate(parsed_args)
            score = results['results'][task_name]['acc,none']
            results_dict[task_name] = score

    print(results_dict)