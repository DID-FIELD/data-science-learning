__version__ = "0.2.7.post3"
from awq.models.auto import AutoAWQForCausalLM
