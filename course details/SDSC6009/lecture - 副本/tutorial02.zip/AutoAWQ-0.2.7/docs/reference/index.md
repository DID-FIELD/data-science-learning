# Auto and Base model classes in AutoAWQ

View the documentation of the main classes of AutoAWQ models below.

::: awq.models.auto.AutoAWQForCausalLM
::: awq.models.base.BaseAWQForCausalLM
